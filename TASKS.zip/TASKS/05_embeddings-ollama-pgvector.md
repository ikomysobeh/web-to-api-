# Work Stream 5 — Embeddings / RAG (Ollama + pgvector)

**Where:** `C:\New folder\webai-bridge\vector.py`, `database.py`, `docker-compose.yml`
**What it is:** A Retrieval-Augmented Generation (RAG) pipeline. Admin-uploaded documents are chunked, embedded locally via **Ollama** (`nomic-embed-text`, 768-dim), and stored in **PostgreSQL with pgvector**. At chat time, the user's message is embedded and the top-5 most similar chunks for that agent are injected into the system prompt — giving agents a private knowledge base. No cloud embedding API, fully local.

**Tech:** Ollama @ `localhost:11434`, pgvector (IVFFlat, cosine), psycopg2, httpx, pypdf, python-docx.

---

## Tasks

### Task 5.1 — Install and configure Ollama for embeddings
**Description:** Install Ollama locally, pull the `nomic-embed-text` model (768-dimensional output), and confirm it serves on `http://localhost:11434`. Wire config into the bridge via `OLLAMA_URL` and `OLLAMA_MODEL` env vars.

### Task 5.2 — Provision pgvector in PostgreSQL
**Description:** Use the `pgvector/pgvector:pg16` Docker image. In `database.py`, run `CREATE EXTENSION IF NOT EXISTS vector` and create the `document_chunks` table with an `embedding vector(768)` column. Add an IVFFlat index `USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100)` for fast approximate cosine search.

### Task 5.3 — Text extraction for multiple file types
**Description:** Implement `extract_text()` in `vector.py` supporting PDF (pypdf), DOCX (python-docx), and TXT/MD (UTF-8 decode with replacement). Returns plain text for downstream chunking.

### Task 5.4 — Chunking with overlap
**Description:** Implement `chunk_text()`: 1500-character chunks (~375 tokens) with 150-character overlap. Split on sentence boundaries first, hard-split only when a sentence exceeds the chunk size, to preserve context across chunk borders.

### Task 5.5 — Embedding generation via Ollama
**Description:** Implement `embed_text()` / `embed_query()` calling `POST {OLLAMA_URL}/api/embeddings` with `{"model": "nomic-embed-text", "prompt": text}` (async httpx, 60s timeout). Return the 768-dim vector; log and return `None` on failure so a single bad chunk doesn't abort ingestion.

### Task 5.6 — Vector storage
**Description:** Implement `store_chunk()` — serialize the embedding to pgvector literal format and `INSERT INTO document_chunks (..., embedding) VALUES (..., %s::vector)` with agent_id, filename, chunk_index, content, and metadata.

### Task 5.7 — Document ingestion pipeline
**Description:** Implement `ingest_document()` orchestrating extract → chunk → embed-each → store, returning a summary `{filename, total_chunks, stored, failed}`. Triggered by the admin document-upload endpoint (Task 3.9).

### Task 5.8 — Agent-scoped semantic search
**Description:** Implement `search_chunks(agent_id, query, limit=5)` — embed the query, then `SELECT content ... WHERE agent_id = %s ORDER BY embedding <=> %s::vector LIMIT %s` (cosine distance). Returns the top-K chunk texts, scoped to the specific agent only.

### Task 5.9 — RAG injection into chat
**Description:** In the chat paths (`/api/chat` and conversation messages), when `agent_id` is present, call `search_chunks` and prepend a "--- Relevant Knowledge ---" block with the retrieved chunks to the agent's instructions in the system prompt before forwarding to WebAI-to-API.

### Task 5.10 — Document setup/architecture notes
**Description:** Maintain `PGVECTOR_OLLAMA_SETUP.md`, `PGVECTOR_PROJECT_ANALYSIS.md`, and `PGVECTOR_RESOURCES.md` describing setup steps, the ingestion/search architecture, model/index choices, and tuning notes (chunk size, overlap, IVFFlat lists).
