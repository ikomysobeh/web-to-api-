# Lumina AI — Project Work Overview (for Task System)

This document lists all work completed across the Lumina AI platform, grouped into 6 work streams. Each linked file contains individual tasks (name + description) ready to be entered into the task system.

## System Architecture (high level)

```
┌──────────────────┐     cookies      ┌──────────────────┐
│ Lumina Extension │ ───────────────► │  Frontend (UI)   │
│ (Chrome, MV3)    │  lumina:gemini-  │  web2api-ui      │
└──────────────────┘     cookies      │  React 19 + Vite │
                                       └────────┬─────────┘
                                                │ JWT (Bearer)
                                                ▼
┌─────────────────────────────────────────────────────────────┐
│                  webai-bridge (FastAPI, Python)               │
│  Auth · Conversations · RAG (pgvector) · Per-user Gemini      │
└───┬───────────────┬──────────────────┬───────────────────────┘
    │ X-Internal-Key│ NATS (auth.v1.*) │ Ollama embeddings
    ▼               ▼                  ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────────┐
│ WebAI-to-API │ │  pizzasys    │ │ Ollama @ :11434  │
│ (Gemini      │ │ (Laravel     │ │ nomic-embed-text │
│  multi-user) │ │  auth + NATS)│ │ + pgvector :5432 │
└──────────────┘ └──────────────┘ └──────────────────┘
```

## Work Streams

| # | Work Stream | File | Summary |
|---|-------------|------|---------|
| 1 | Browser Extension | [01_lumina-extension.md](01_lumina-extension.md) | Chrome MV3 extension that captures Gemini cookies and sends them to the UI |
| 2 | Frontend | [02_frontend-web2api-ui.md](02_frontend-web2api-ui.md) | React 19 chat UI + admin dashboard (agents, users, RAG documents) |
| 3 | Backend Bridge | [03_backend-webai-bridge.md](03_backend-webai-bridge.md) | FastAPI service: auth, conversations, RAG, per-user Gemini orchestration |
| 4 | WebAI-to-API (multi-user) | [04_webai-to-api-multiuser.md](04_webai-to-api-multiuser.md) | Modified open-source Gemini wrapper to support many concurrent users |
| 5 | Embeddings / RAG | [05_embeddings-ollama-pgvector.md](05_embeddings-ollama-pgvector.md) | Ollama + pgvector document ingestion and semantic search |
| 6 | Auth + NATS | [06_auth-nats-pizzasys.md](06_auth-nats-pizzasys.md) | Centralized Laravel auth (pizzasys) syncing users to the bridge over NATS |

## Tech Stack Summary

- **Extension:** React 19, TypeScript, Vite, Manifest V3, Chrome cookies/tabs APIs
- **Frontend:** React 19, TypeScript, Vite, Tailwind 4, Zustand, Vercel AI SDK, React Router 7
- **Bridge:** FastAPI, PostgreSQL + pgvector, JWT/Sanctum, NATS (nats-py), Ollama, httpx
- **WebAI-to-API:** FastAPI, gemini_webapi, SQLite (per-user session snapshots)
- **Embeddings:** Ollama (nomic-embed-text, 768-dim), pgvector (IVFFlat, cosine)
- **Auth:** Laravel 12, Sanctum, Spatie Permissions, NATS JetStream (AUTH_EVENTS stream)
- **Infra:** Docker Compose (pgvector/pgvector:pg16, NATS, bridge, WebAI-to-API)
