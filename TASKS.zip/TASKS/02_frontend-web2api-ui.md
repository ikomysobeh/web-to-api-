# Work Stream 2 — Frontend (web2api-ui)

**Repo:** `C:\New folder\web2api-ui`
**What it is:** The Lumina AI web application — a modern chat interface with a full admin dashboard. Users chat with Gemini-backed models and custom AI agents; admins manage agents, their knowledge-base documents (RAG), and user assignments.

**Tech:** React 19, TypeScript, Vite 8, Tailwind 4, Zustand, React Router 7, Vercel AI SDK (`ai`), Streamdown (markdown/code/math/mermaid rendering), Shiki, Lucide icons. ~109 TS/TSX files.

---

## Tasks

### Task 2.1 — Project setup and design system
**Description:** Scaffold the React 19 + Vite + TypeScript app with Tailwind 4. Build the glassmorphism design system in `src/index.css` (`.glass`, `.glass-nav`, `.glass-strong`), aurora gradient background, Geist typography, and custom scrollbars. Dark theme only.

### Task 2.2 — Authentication flow and route guards
**Description:** Build `LoginPage.tsx`, `AuthContext.tsx`, and `ProtectedRoute`/`AdminRoute` guards. On login, POST to the external auth service (`VITE_AUTH_URL`), store JWT + email in localStorage, validate token on mount via `GET /auth/me`, and detect admin via `global_roles` (`admin`/`super-admin`). Redirect unauthenticated users to `/login` and non-admins away from admin routes.

### Task 2.3 — Centralized API service layer
**Description:** Implement `src/services/api.ts` as the single source for all backend calls (auth, conversations, messages, models, cookies, agents, admin). Read base URLs from env (`VITE_API_URL`, `VITE_AUTH_URL`), attach Bearer token to every request, and handle streaming responses.

### Task 2.4 — Chat interface (AppShell)
**Description:** Build the main chat experience: `AppShell`, `ChatHome` (empty state with model/agent selection + suggestion cards), `ChatMessages` (streaming message thread), `Sidebar`/`MobileSidebar` (conversation list grouped by date, rename/delete), and `TopBar`. Use Zustand `conversationStore` for state with optimistic updates and rollback on error.

### Task 2.5 — Advanced chat input
**Description:** Build `ChatInput.tsx` with a model selector, an agent/bot selector dropdown, mic button for speech-to-text (`react-speech-recognition`), image attachment support, and submit via button or Shift+Enter.

### Task 2.6 — Rich AI content rendering
**Description:** Integrate Streamdown + Shiki to render streamed assistant output: code blocks with syntax highlighting, math, mermaid diagrams, artifacts, reasoning chains, images, and audio. Handle partial JSON chunks during SSE streaming.

### Task 2.7 — Admin dashboard — Agents CRUD
**Description:** Build `AdminShell`, `AdminDashboard`, `AgentsPage`, `AgentDetailPage`, and `AgentFormModal`. Support create/edit/deactivate agents with name, description, model, and system instructions. Wire to `/admin/agents` endpoints via `adminStore`.

### Task 2.8 — Admin dashboard — RAG document management
**Description:** In `AgentDetailPage`, build document upload/list/delete UI for an agent's knowledge base (PDF/DOCX/TXT/MD). Show chunk counts. Wire to `/admin/agents/{id}/documents` endpoints.

### Task 2.9 — Admin dashboard — User assignment & user list
**Description:** Build `UsersPage` (list system users with role badges) and the per-agent user-assignment UI (assign/remove users who can use an agent). Wire to `/admin/agents/{id}/users` and `/users` endpoints.

### Task 2.10 — Gemini connection via extension (CookieSetupModal)
**Description:** Build `CookieSetupModal.tsx` and the `useExtensionCookies` hook. Listen for the `lumina:gemini-cookies` DOM event from the browser extension, receive `{psid, psidts}`, and POST them to `POST /api/cookies`. Provide a step-by-step extension install guide and a manual-paste fallback.

### Task 2.11 — Settings, profile, and model selection
**Description:** Build `SettingsModal` for user preferences (default model, theme) wired to `/api/user/profile`, and the models dropdown sourced from `/api/models`.
