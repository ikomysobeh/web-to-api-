# Work Stream 1 — Lumina Browser Extension

**Repo:** `C:\lumina-extension (4)\lumina-extension`
**What it is:** A Chrome (Manifest V3) browser extension named **"Lumina AI — Gemini Cookie Helper"**. It securely reads the user's Google Gemini session cookies (`__Secure-1PSID`, `__Secure-1PSIDTS`) from the browser and delivers them to the Lumina AI web app running locally, so the backend can act on the user's Gemini session without the user ever copying credentials manually.

**Tech:** React 19, TypeScript, Vite 8, TailwindCSS 4, Shadcn/Radix UI, Manifest V3 service worker.

---

## Tasks

### Task 1.1 — Scaffold Manifest V3 extension project
**Description:** Set up the Chrome extension project using Vite + React 19 + TypeScript with a dual-entry build (popup UI + content script). Configure `vite.config.ts` to output `content.js` with a stable (non-hashed) name so the manifest can reference it. Add Tailwind 4 and Shadcn/Radix UI for the popup.

### Task 1.2 — Define manifest permissions and host access
**Description:** Author `public/manifest.json` (MV3) requesting `cookies`, `activeTab`, `clipboardWrite`, and `tabs` permissions. Restrict host permissions to `https://gemini.google.com/*`, `http://localhost:5173/*`, `http://localhost:3000/*`, and `http://127.0.0.1:3000/*`. Register the background service worker and content script.

### Task 1.3 — Build cookie extraction in the background service worker
**Description:** Implement `public/background.js` to listen for a `GET_GEMINI_COOKIES` runtime message and use `chrome.cookies.get()` to read `__Secure-1PSID` and `__Secure-1PSIDTS` from `https://gemini.google.com`. Return success/failure plus cookie values in-memory only — cookies are never stored or logged.

### Task 1.4 — Build the popup UI (Capture & Send / Copy to Clipboard)
**Description:** Implement `src/App.tsx` popup with two actions: (1) **Capture & Send** — detect an open Gemini tab, pull cookies via the background worker, locate the Lumina tab (`localhost:3000`) and push cookies via `chrome.tabs.sendMessage`; (2) **Copy to Clipboard** — fallback that formats cookies as text for manual paste. Show live status (Gemini tab detected / open Gemini first / checking).

### Task 1.5 — Build content-script bridge to the web app
**Description:** Implement `src/content/receiver.ts` injected into the Lumina tab. It listens for the `LUMINA_COOKIES` runtime message and re-dispatches it as a DOM `CustomEvent('lumina:gemini-cookies')` on `window`, which the React app consumes via the `useExtensionCookies` hook. This decouples the extension from the app's internal state.

### Task 1.6 — Document install + usage flow
**Description:** Write setup instructions: load unpacked extension, open Gemini and sign in, open Lumina, click Capture & Send. Document the end-to-end flow and the clipboard fallback for environments where direct messaging fails.
