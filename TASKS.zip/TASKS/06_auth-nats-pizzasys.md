# Work Stream 6 — Centralized Auth + NATS Sync (pizzasys)

**Repos:** `C:\xampp\htdocs\projacet\pizzasys` (Laravel auth) ↔ `C:\New folder\webai-bridge\nats_sync.py` (Python consumer)
**What it is:** **pizzasys** is the authoritative authentication system (Laravel 12, Sanctum tokens, Spatie roles/permissions, multi-tenant stores). It publishes user lifecycle events to **NATS JetStream** using a transactional outbox. Downstream systems — including **webai-bridge** — subscribe with durable consumers and keep their own user tables in sync. The bridge also verifies tokens against pizzasys over HTTP. This work stream was set up and run locally to test the NATS link end-to-end.

**Tech:** Laravel 12, Sanctum, Spatie Permissions, NATS JetStream (`AUTH_EVENTS` stream, `auth.v1.>` subjects, port 4222), nats-py (Python side), MySQL (pizzasys) + PostgreSQL (bridge).

---

## Tasks

### Task 6.1 — Stand up pizzasys locally
**Description:** Install and run the pizzasys Laravel app on the local machine (XAMPP). Configure `.env` (MySQL `pizzasys` DB, app URL/port), run migrations and seeders for users, Spatie roles/permissions, stores, role hierarchy, service clients, and the `auth_outbox_events` table.

### Task 6.2 — Configure NATS server + connection
**Description:** Run a local NATS server (port 4222) with token auth (`NATS_TOKEN=localdev`). Configure `config/nats.php` and `.env` on the pizzasys side: host, port, token, JetStream enabled, stream `AUTH_EVENTS`, subjects `auth.v1.>`.

### Task 6.3 — Verify the transactional outbox publisher
**Description:** Confirm the auth-event pipeline: `AuthOutboxService` writes events to `auth_outbox_events`, `PublishAuthOutboxEventJob` (queue=database, tries=10, dispatched via `DB::afterCommit()`) publishes them through `JetStreamPublisher` with ACK validation, and `AuthEventFactory` wraps each in a CloudEvents v1.0 envelope. Ensure events publish only after the DB transaction commits.

### Task 6.4 — Confirm published event catalog
**Description:** Verify pizzasys emits the expected subjects on user changes: `auth.v1.user.created`, `user.updated`, `user.deleted`, `user.role.assigned`, `user.role.removed`, `user.role.synced`, `user.permission.granted/revoked/synced` — emitted from `UserManagementService` create/update/delete/role/permission operations.

### Task 6.5 — Build the Python NATS consumer in the bridge
**Description:** Implement/verify `nats_sync.py`: connect to `NATS_URL` (token or user/pass), create a JetStream durable consumer (`WEBAI_BRIDGE_AUTH_CONSUMER`) on the `AUTH_EVENTS` stream, and subscribe to user + role subjects. Support `DEV_MODE=1` to switch the subject prefix to `auth.testing.v1.*`. Run it as a background asyncio task on bridge startup.

### Task 6.6 — Implement event handlers (user sync)
**Description:** Implement handlers: `handle_user_created` (upsert into Postgres `users`), `handle_user_updated` (update email on change), `handle_user_deleted` (cascade-delete user + conversations + messages), and `handle_role_changed` (map Laravel roles → bridge role: `super-admin`/`admin` → `admin`, else `user`). Use durable consumers so missed events replay on reconnect.

### Task 6.7 — HTTP token verification path
**Description:** Configure the bridge to verify Sanctum tokens against pizzasys `POST /api/v1/auth/token-verify` using a service-client token (`AUTH_SERVER_*` env vars), returning user_id/email/roles/permissions and auto-upserting the user. This complements NATS sync so a freshly-created user works immediately without waiting for the event.

### Task 6.8 — Create a service client for the bridge
**Description:** In pizzasys, register a `service_client` for webai-bridge (token hashed with SHA256, `is_active=true`). Provide its token to the bridge as `AUTH_SERVER_CALL_TOKEN` so token-verify calls are authorized.

### Task 6.9 — End-to-end local test
**Description:** Test the full link on the local machine: create/update/delete a user and assign roles in pizzasys, observe the events flow through NATS, and confirm the bridge's Postgres `users` table reflects the change (including admin role mapping). Use `GET /health/nats` to confirm the consumer connection.

### Task 6.10 — Document the NATS architecture
**Description:** Maintain `NATS_COMPLETE_GUIDE.md`, `NATS_COMPARISON_GUIDE.md`, and `HIRINGPIZZA_AUTH_GUIDE.md`: the three-player topology (pizzasys → NATS → bridge/HiringPizza), event payload formats, dev-mode subjects, durable-consumer replay, the `/api/v1/auth/token-verify` flow, and a troubleshooting checklist.
