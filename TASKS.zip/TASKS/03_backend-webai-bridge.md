# Work Stream 3 — Backend Bridge (webai-bridge)

**Repo:** `C:\New folder\webai-bridge`
**What it is:** The core FastAPI service that sits between the frontend and everything else. It handles authentication, stores conversations/messages, runs RAG (vector search), orchestrates per-user Gemini access through WebAI-to-API, and stays in sync with the central auth system over NATS.

**Tech:** FastAPI, Uvicorn, PostgreSQL (psycopg2 + pgvector), python-jose (JWT), passlib + bcrypt, httpx, nats-py, ollama, pypdf/python-docx, browser-cookie3, Fernet encryption.

---

## Tasks

### Task 3.1 — FastAPI app skeleton + PostgreSQL schema
**Description:** Set up `main.py` (FastAPI app, CORS for localhost:3000/5173, startup hooks) and `database.py` with `init_db()` creating tables: `users`, `user_gemini_cookies`, `conversations`, `conversation_messages`, `user_preferences`, `agents`, `document_chunks`, `user_agents`. Enable `uuid-ossp` and `vector` extensions.

### Task 3.2 — Dual-mode authentication system
**Description:** Implement `auth.py` supporting two modes: (1) **pizzasys token verification** — call `POST /api/v1/auth/token-verify` on the auth server with a service token, returning user_id/email/roles/permissions and auto-upserting the user locally; (2) **local JWT fallback** — HS256 tokens (7-day expiry) signed with `SECRET_KEY`. Add `require_admin` and `require_permission(...)` dependencies. Hash passwords with bcrypt.

### Task 3.3 — Auth endpoints
**Description:** Build `POST /auth/register`, `POST /auth/login`, and `GET /auth/me`. Register validates email/password and issues a token; login authenticates (locally or via pizzasys); me returns the current user.

### Task 3.4 — Per-user Gemini cookie management
**Description:** Build `cookie_service.py` (Fernet encrypt/decrypt, save/load/has/delete) and endpoints: `POST /api/cookies` (save + create WebAI client), `POST /api/cookies/extract` (auto-read from local browser via browser-cookie3), `GET /api/cookies/status`, `DELETE /api/cookies` (disconnect + drop client). Cookies are always stored encrypted.

### Task 3.5 — Chat proxy with streaming + agent/RAG injection
**Description:** Build `POST /api/chat`. Stream from WebAI-to-API `POST /v1/chat/completions` passing `X-Internal-Key` and `X-Internal-User-ID`. When an `agent_id` is supplied, fetch the agent's instructions, run vector search for the top-5 relevant chunks, and inject them into the system prompt before forwarding. Relay the SSE stream back to the client.

### Task 3.6 — Conversation CRUD
**Description:** Build `conversation_service.py` and endpoints: list (paginated), create, get-with-messages, update (title/model), delete one, delete all. All queries are scoped by `user_id` for ownership enforcement.

### Task 3.7 — Message CRUD + persistence during streaming
**Description:** Build `message_service.py` and endpoints under `/api/conversations/{id}/messages`: send (streams response and saves both user + assistant messages), list (paginated), delete. Saves assistant content accumulated from the SSE stream on completion.

### Task 3.8 — Admin: Agents CRUD
**Description:** Build admin endpoints `GET/POST /admin/agents`, `GET/PUT/DELETE /admin/agents/{id}` (soft delete via `is_active`). Guarded by `require_admin`. Agents store name, description, instructions, model, created_by.

### Task 3.9 — Admin: document ingestion + listing
**Description:** Build `POST /admin/agents/{id}/documents` (upload PDF/DOCX/TXT/MD → extract → chunk → embed → store), `GET .../documents` (grouped by filename with chunk counts), `DELETE .../documents/{filename}`. See Work Stream 5 for the embedding pipeline detail.

### Task 3.10 — Admin: user-to-agent assignment + user list
**Description:** Build `GET/POST /admin/agents/{id}/users`, `DELETE /admin/agents/{id}/users/{user_id}`, and `GET /admin/users`. Note: role changes are owned by pizzasys, so `PUT /admin/users/{id}/role` returns an explanatory error rather than mutating roles locally.

### Task 3.11 — User-facing agent discovery
**Description:** Build `GET /api/agents` (agents assigned to the current user, instructions hidden) and `GET /api/agents/{id}` (details without exposing instructions).

### Task 3.12 — User profile, models, and Gemini status endpoints
**Description:** Build `GET/PUT /api/user/profile` (preferences), `POST /api/user/logout`, `GET /api/models`, `GET /api/gemini/status`, and `POST /api/gemini/disconnect`.

### Task 3.13 — Health and debug endpoints
**Description:** Build `GET /health`, `GET /health/nats` (NATS connection state), and `GET /api/debug/session-registry` (checks whether a user's session exists in WebAI-to-API).

### Task 3.14 — Pydantic schemas
**Description:** Define request/response models in `schemas/`: conversations, messages, users, agents (admin vs. public views), documents, and shared dataclasses.

### Task 3.15 — Bug fix: UUID validation on conversation/message routes
**Description:** Fixed `invalid input syntax for type uuid` (500 error) when a non-UUID id (e.g. `/api/conversations/1`) was passed. Changed path params to FastAPI `UUID` type for early `422` validation, and added a `_validate_uuid` safety-net helper in `conversation_service.py` and `message_service.py`.

### Task 3.16 — Bug fix: bcrypt/passlib version warning
**Description:** Address the `AttributeError: module 'bcrypt' has no attribute '__about__'` warning on registration by pinning a compatible `bcrypt` version in `requirements.txt`. (Non-blocking — hashing still succeeds.)
