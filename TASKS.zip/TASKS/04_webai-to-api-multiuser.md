# Work Stream 4 — WebAI-to-API Multi-User Modifications

**Repo:** `C:\New folder\WebAI-to-API`
**What it is:** A cloned open-source project that wraps the Google Gemini web session as an OpenAI-compatible REST API (`/v1/chat/completions`). The original was **single-user** (one global Gemini client, one global session registry). We **modified it to support many concurrent users**, each with their own Gemini cookies, isolated sessions, and isolated conversation storage — driven by the bridge over internal endpoints.

**Tech:** FastAPI, gemini_webapi, SQLite (per-user session snapshots), Pydantic.

---

## Tasks

### Task 4.1 — Per-user Gemini client pool
**Description:** Created `src/app/services/gemini_client_manager.py` — a registry mapping `user_id → MyGeminiClient`, replacing the single global client. `get_or_create_client()` reuses or creates a client under an `asyncio.Lock`; `get_client()` does a synchronous lookup; `remove_client()` closes and removes a client. Each user gets a unique temp cookie path so users never share cache files.

### Task 4.2 — Retry logic for UNAUTHENTICATED initialization
**Description:** In `_create_client()`, added a retry loop (3 attempts, 2s delay) that creates a **fresh** client instance with a new temp path on each attempt. This works around gemini_webapi reporting `UNAUTHENTICATED` on a first init even with valid cookies (internal token refresh) — a clean second instance reaches `AVAILABLE`. Raises `RuntimeError` if all attempts fail.

### Task 4.3 — Internal management endpoints (bridge-facing)
**Description:** In `src/app/endpoints/system.py`, added internal endpoints protected by an `X-Internal-Key` header: `POST /internal/gemini/create` (create a user's client, returns status), `DELETE /internal/gemini/{user_id}` (remove a user's client), `GET /internal/gemini/active` (list active users). Only the bridge knows the key.

### Task 4.4 — Per-user session registries
**Description:** In `src/app/services/providers/gemini/session_manager.py`, added `_per_user_registries` plus `get_or_create_user_registry()`, `get_user_registry()`, and `remove_user_registry()`. Each user gets an isolated `SessionRegistry` with its own SQLite conversation repository, so one user can never read another's conversations. The legacy global registry is kept for backward compatibility.

### Task 4.5 — Wire registry lifecycle into the client pool
**Description:** Linked client and registry lifecycles: `get_or_create_client()` creates the per-user registry immediately after creating the client (so chat requests never race a missing registry), and `remove_client()` calls `remove_user_registry()` to prevent leaks.

### Task 4.6 — Route chat requests by X-Internal-User-ID
**Description:** In `src/app/services/providers/gemini/webapi_adapter.py`, `chat_completions()` reads `request._user_id` and, when present, fetches the per-user client (`_get_available_gemini_client(user_id)`) and per-user registry (`get_user_registry(user_id)`); otherwise it falls back to the legacy global path. The chat endpoint reads the `X-Internal-User-ID` header and attaches it to the request so it flows endpoint → provider → adapter → client/registry.

### Task 4.7 — Fix: "Session registry is not initialized" (503)
**Description:** Root cause — in multi-user mode the global registry is never initialized (no global cookies), so chat requests 503'd. Fixed by Tasks 4.4–4.6 (per-user registry created at client-creation time and selected by user_id at chat time). Verified user 5's chat path no longer 503s after connecting.

### Task 4.8 — Verify isolation and backward compatibility
**Description:** Confirm complete per-user isolation (separate cookies, sessions, SQLite snapshots) and that requests without `X-Internal-User-ID` still use the original single-user global path. Document the original-vs-modified architecture for handoff.
